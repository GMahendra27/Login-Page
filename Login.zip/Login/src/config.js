const mongoose = require("mongoose");

// Connect to MongoDB
const connect = mongoose.connect("mongodb://localhost:27017/Login", { 
    useNewUrlParser: true,
    useUnifiedTopology: true 
});

connect.then(() => {
    console.log("Connected to MongoDB");
}).catch((error) => {
    console.log("Error connecting to MongoDB: ", error);
});

// Define the schema
const LoginSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    password: {
        type: String,
        required: true
    }
});

// Create and export the model
const UserModel = mongoose.model("User", LoginSchema); // Use a meaningful name for the model
module.exports = UserModel; // Export the model instead of the collection
