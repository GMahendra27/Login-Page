const express = require('express'); 
const path = require("path"); 
const bcrypt = require("bcrypt");
const UserModel = require("./config"); // Make sure to import the model correctly
const app = express();

// Middleware to convert data into JSON format
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Set EJS as the view engine
app.set('view engine', 'ejs');

// Route for the login page
app.get("/", (req, res) => {
    res.render("login");
});

// Route for the signup page
app.get("/signup", (req, res) => { 
    res.render("signup");
});

// Register User
app.post("/signup", async (req, res) => {
    try {
        const data = {
            name: req.body.username, // Get username from the form
            password: await bcrypt.hash(req.body.password, 10) // Hash the password
        };

        // Check if the user already exists
        const existingUser = await UserModel.findOne({ name: data.name });
        if (existingUser) {
            return res.send("User already exists. Please choose a different username.");
        }

        // Insert the user data into the collection if they don't exist
        const userdata = await UserModel.create(data); // Use create instead of insertOne for a single document
        console.log(userdata);
        res.send("User registered successfully");

    } catch (error) {
        console.error("Error registering user: ", error.message); // Log error message
        res.status(500).send("An error occurred while registering the user: " + error.message); // Return error message to the client
    }
});

// Login User
app.post("/login", async (req, res) => {
    try {
        // Find the user by username
        const user = await UserModel.findOne({ name: req.body.username });
        
        // Check if the user exists
        if (!user) {
            return res.send("Username not found");
        }

        // Compare the hashed password from the database with the plain text password
        const isPasswordMatch = await bcrypt.compare(req.body.password, user.password);
        
        // If the password matches, render the home page; otherwise, send an error message
        if (isPasswordMatch) {
            res.render("home"); // Ensure you have a home.ejs file to render
        } else {
            res.send("Wrong password");
        }
    } catch (error) {
        console.error("Error during login: ", error);
        res.send("An error occurred during login");
    }
});

// Set up the server
const port = 3000;
app.listen(port, () => {
    console.log(`Server running on Port: ${port}`); // Log the server port
});
